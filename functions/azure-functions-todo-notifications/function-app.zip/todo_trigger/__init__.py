import logging
from datetime import datetime, timedelta

import azure.functions as func
from shared.email_service import send_email
from shared.todo_service import get_assignee_email, get_todo_items


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("Processing a new or updated todo item.")

    # Get the todo item details from the request
    todo_item = req.get_json()
    assignee = todo_item.get("assignee")
    due_date = todo_item.get("due_date")
    status = todo_item.get("status")

    # Check if the assignee is provided
    if not assignee:
        return func.HttpResponse("Assignee is required.", status_code=400)

    # Get the assignee's email
    assignee_email = get_assignee_email(assignee)

    # Notify immediately on creation or update
    if todo_item.get("is_new") or todo_item.get("is_updated"):
        send_email(
            assignee_email,
            "Todo Item Notification",
            f"You have a new todo item: {todo_item.get('title')}.",
        )

    # Check for reminders based on due date and status
    if due_date:
        due_date_obj = datetime.strptime(due_date, "%Y-%m-%d")
        today = datetime.now()

        # Send reminder one day before due date
        if (
            due_date_obj - timedelta(days=1)
        ).date() == today.date() and status != "Completed":
            send_email(
                assignee_email,
                "Todo Reminder",
                f"Reminder: Your todo item '{todo_item.get('title')}' is due tomorrow.",
            )

        # Send reminder if overdue and status is NotStarted
        if today.date() > due_date_obj.date() and status == "NotStarted":
            send_email(
                assignee_email,
                "Overdue Todo Reminder",
                f"Your todo item '{todo_item.get('title')}' is overdue.",
            )

    return func.HttpResponse("Notification processed.", status_code=200)
